from rstools import RSoftCircuit

import numpy as np, json
from HexProperties import generate_hex_grid, number_rows

# name the output file
name = 'MCF_Test'

# Collection of symbols to use wihtin the RSoft CAD
sym = {}

#############################################################################################################################################################################################
''' 
Define the fibre and RSoft properties 
'''

# properties of the structure (units of um)
with open("fibre_prop.json", "r") as f:
    params = json.load(f)

for key in params:
    sym[key] = params[key]
    
sym['H'] = 'height'

# simulation settings
sym['Dx'] = 0.1
sym['Dy'] = sym['Dx']
sym['Dz'] = 0.2
sym['Phase'] = 0
sym['boundary_gap_x'] = 10
sym['boundary_gap_y'] = sym['boundary_gap_x']
sym['boundary_gap_z'] = 0
sym['bpm_pathway'] = 1
sym['bpm_pathway_monitor'] = sym['bpm_pathway']
sym['sym_tool'] = 'ST_BEAMPROP'
sym['width'] = 5
sym['height'] = sym['width']
sym['background_index'] = params["background_index"]
sym['grid_nonuniform'] = 0
sym['eim'] = 0
sym['polarization'] = 0
sym['free_space_wavelength'] = 1
sym['k0'] = 2*np.pi / sym['free_space_wavelength']
sym['slice_display_mode'] = 'DISPLAY_CONTOURMAPXZ'
sym['slice_position_z'] = 100

# launch properties
sym['launch_tilt'] = 1
sym['launch_port'] = 1
sym['launch_align_file'] = 1
sym['launch_mode'] = 0
sym['launch_mode_radial'] = 1
sym['launch_normalization'] = 1
sym['grid_size'] = 'Dx'
sym['grid_size_y'] = 'Dy'
sym['step_size'] = 'Dz'

# set the global segment structure, other use segment.structure( ‘FIBER’ )
sym['structure'] = 'STRUCT_FIBER'

# creating the design file, load the seetings and add symbols
c = RSoftCircuit()
for key in sym:
    c.set_symbol(key,sym[key])

#############################################################################################################################################################################################
''' 
Generating the positional coordinates for each fibre 
'''
# # this must be an odd number!!
# core_num = [sym['core_num']]

# for i in range(len(core_num)):
#     if core_num[i] % 2 == 0:
#         raise ValueError(f"The number of cores must be odd to perfectly fit inside the hex grid. Received:{core_num}")
    
# row_numbers = [number_rows(n) for n in core_num]

# for idx, row_num in enumerate(row_numbers):
#     hcoord, vcoord = generate_hex_grid(row_num, sym["Core_sep"])

#############################################################################################################################################################################################
''' 
Generating the segments and assigning the positional coordinates found in 
the previous sections 
'''

# core_name = [f"core_{n+1:02}" for n in range(7)]

cladding = c.add_segment(
                position=(0,0,0), offset=(0,0,'Length'), 
                dimensions = ('Corediam','Corediam'), # /sym['taper_ratio']
                dimensions_end = (('Corediam', 'Corediam'))
                )

cladding.set_name("Core")

# for j, (x, y) in enumerate(zip(hcoord, vcoord)):

#     core = c.add_segment(position=(x/sym['taper_ratio'],y/sym['taper_ratio'],0), offset=(x,y,'Length'), 
#                 dimensions = (sym['Corediam']/sym['taper_ratio'], sym['Corediam']/sym['taper_ratio']), 
#                 dimensions_end = (('Corediam', 'Corediam')))

#     core.set_name(core_name[j])

#############################################################################################################################################################################################

c.write('%s.ind'%name)