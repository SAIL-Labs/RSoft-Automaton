
# Function to extract parameters from the .ind file
def Extract_params(param=""):
    with open("MCF_Test.ind", "r") as r:
        for line in r:
            if param in line:
                key, value = line.split("=")
                key = key.strip()
                val = float(value.strip())
                break # <-- stop reading the file once found
    return val

def insert_param_into_file(file_path, param):
    with open(file_path, "r") as f:
        lines = f.readlines()

    new_lines = []
    for i, line in enumerate(lines):
        new_lines.append(line)
        if line.strip().startswith("begin.width"):
            new_lines.append(f"\tbegin.delta = {param}\n")
        elif line.strip().startswith("end.width"):
            new_lines.append(f"\tend.delta = {param}\n")

    with open(file_path, "w") as f:
        f.writelines(new_lines)